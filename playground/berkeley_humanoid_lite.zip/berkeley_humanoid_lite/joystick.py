    class Joystick(bhl_base.BHLEnv):
        """Track a joystick command."""

        def __init__(
            self,
            task: str = "flat_terrain",
            config: config_dict.ConfigDict = default_config(),
            config_overrides: Optional[Dict[str, Union[str, int, list[Any]]]] = None,
        ):
            super().__init__(
                xml_path=constants.task_to_xml(task).as_posix(),
                config=config,
                config_overrides=config_overrides,
            )
            self._post_init()

        # ---------------------------------------------------------------------
        # NEW: helper to compute smoothed motor targets
        # ---------------------------------------------------------------------
        def _compute_motor_targets(
            self,
            prev_motor_targets: jax.Array,
            action_command: jax.Array,
        ) -> jax.Array:
            """
            Hybrid motor target update.

            1. Treat the policy output as an absolute offset from the 'home' /
               neutral pose (self._default_actuator), like your current code.
            2. Move toward that pose gradually, limited by max_motor_velocity * dt,
               like your existing clip logic, so you don't teleport joints.

            This keeps learning simple (policy controls pose directly)
            but enforces physical-ish slew limits.
            """

            # Proposed absolute targets (Version B style).
            proposed = (
                self._default_actuator
                + action_command * self._config.action_scale
            )  # <<< ADDED

            # Delta from where we were last step.
            delta = proposed - prev_motor_targets  # <<< ADDED

            # Apply per-step velocity limit (Version A spirit).
            if USE_MOTOR_SPEED_LIMITS:  # <<< CHANGED (reuse your flag)
                max_step = self._config.max_motor_velocity * self.dt  # rad/s * s -> rad  # <<< ADDED
                delta = jp.clip(delta, -max_step, max_step)  # <<< ADDED

            # New targets = last targets + safe delta.
            next_targets = prev_motor_targets + delta  # <<< ADDED
            return next_targets  # <<< ADDED
        # ---------------------------------------------------------------------

        def _post_init(self) -> None:

            self._init_q = jp.array(self._mj_model.keyframe("home").qpos)
            self._default_actuator = self._mj_model.keyframe(
                "home"
            ).ctrl  # ctrl of all the actual joints (no floating base and no backlash)

            if USE_IMITATION_REWARD:
                self.PRM = PolyReferenceMotion(
                    "playground/berkeley_humanoid_lite/data/polynomial_coefficients.pkl"
                )

            # Note: First joint is freejoint.
            # get the range of the joints
            self._lowers, self._uppers = self.mj_model.jnt_range[1:].T
            c = (self._lowers + self._uppers) / 2
            r = self._uppers - self._lowers
            self._soft_lowers = c - 0.5 * r * self._config.soft_joint_pos_limit_factor
            self._soft_uppers = c + 0.5 * r * self._config.soft_joint_pos_limit_factor

            # weights for computing the cost of each joints compared to a reference pose
            self._weights = jp.array(
                [
                    1.0,
                    1.0,
                    0.01,
                    0.01,
                    1.0,  # left leg.
                    # 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, #head
                    1.0,
                    1.0,
                    0.01,
                    0.01,
                    1.0,  # right leg.
                ]
            )

            self._njoints = self._mj_model.njnt  # number of joints
            self._actuators = self._mj_model.nu  # number of actuators

            self._torso_body_id = self._mj_model.body(constants.ROOT_BODY).id
            self._torso_mass = self._mj_model.body_subtreemass[self._torso_body_id]
            self._site_id = self._mj_model.site("torso").id

            self._feet_site_id = np.array(
                [self._mj_model.site(name).id for name in constants.FEET_SITES]
            )
            self._floor_geom_id = self._mj_model.geom("floor").id
            self._feet_geom_id = np.array(
                [self._mj_model.geom(name).id for name in constants.FEET_GEOMS]
            )

            foot_linvel_sensor_adr = []
            for site in constants.FEET_SITES:
                sensor_id = self._mj_model.sensor(f"{site}_global_linvel").id
                sensor_adr = self._mj_model.sensor_adr[sensor_id]
                sensor_dim = self._mj_model.sensor_dim[sensor_id]
                foot_linvel_sensor_adr.append(
                    list(range(sensor_adr, sensor_adr + sensor_dim))
                )
            self._foot_linvel_sensor_adr = jp.array(foot_linvel_sensor_adr)

            # # noise in the simu?
            qpos_noise_scale = np.zeros(self._actuators)

            hip_ids = [
                idx for idx, j in enumerate(constants.JOINTS_ORDER_NO_HEAD) if "_hip" in j
            ]
            knee_ids = [
                idx for idx, j in enumerate(constants.JOINTS_ORDER_NO_HEAD) if "_knee" in j
            ]
            ankle_ids = [
                idx for idx, j in enumerate(constants.JOINTS_ORDER_NO_HEAD) if "_ankle" in j
            ]

            qpos_noise_scale[hip_ids] = self._config.noise_config.scales.hip_pos
            qpos_noise_scale[knee_ids] = self._config.noise_config.scales.knee_pos
            qpos_noise_scale[ankle_ids] = self._config.noise_config.scales.ankle_pos
            # qpos_noise_scale[faa_ids] = self._config.noise_config.scales.faa_pos
            self._qpos_noise_scale = jp.array(qpos_noise_scale)

            # self.action_filter = LowPassActionFilter(
            #     1 / self._config.ctrl_dt, cutoff_frequency=37.5
            # )

        def reset(self, rng: jax.Array) -> mjx_env.State:
            qpos = self._init_q  # the complete qpos
            # print(f'DEBUG0 init qpos: {qpos}')
            qvel = jp.zeros(self.mjx_model.nv)

            # init position/orientation in environment
            # x=+U(-0.05, 0.05), y=+U(-0.05, 0.05), yaw=U(-3.14, 3.14).
            rng, key = jax.random.split(rng)
            dxy = jax.random.uniform(key, (2,), minval=-0.05, maxval=0.05)

            # floating base
            base_qpos = self.get_floating_base_qpos(qpos)
            base_qpos = base_qpos.at[0:2].set(
                qpos[self._floating_base_qpos_addr : self._floating_base_qpos_addr + 2]
                + dxy
            )  # x y noise

            rng, key = jax.random.split(rng)
            yaw = jax.random.uniform(key, (1,), minval=-3.14, maxval=3.14)
            quat = math.axis_angle_to_quat(jp.array([0, 0, 1]), yaw)
            new_quat = math.quat_mul(
                qpos[self._floating_base_qpos_addr + 3 : self._floating_base_qpos_addr + 7],
                quat,
            )  # yaw noise

            base_qpos = base_qpos.at[3:7].set(new_quat)

            qpos = self.set_floating_base_qpos(base_qpos, qpos)
            # print(f'DEBUG1 base qpos: {qpos}')
            # init joint position
            # qpos[7:]=*U(0.0, 0.1)
            rng, key = jax.random.split(rng)

            # multiply actual joints with noise (excluding floating base and backlash)
            qpos_j = self.get_actuator_joints_qpos(qpos) * jax.random.uniform(
                key, (self._actuators,), minval=0.5, maxval=1.5
            )
            qpos = self.set_actuator_joints_qpos(qpos_j, qpos)
            # print(f'DEBUG2 joint qpos: {qpos}')
            # init joint vel
            # d(xyzrpy)=U(-0.05, 0.05)
            rng, key = jax.random.split(rng)
            # qvel = qvel.at[self._floating_base_qvel_addr : self._floating_base_qvel_addr + 6].set(
            #     jax.random.uniform(key, (6,), minval=-0.5, maxval=0.5)
            # )

            qvel = self.set_floating_base_qvel(
                jax.random.uniform(key, (6,), minval=-0.05, maxval=0.05), qvel
            )
            # print(f'DEBUG3 base qvel: {qvel}')
            ctrl = self.get_actuator_joints_qpos(qpos)
            # print(f'DEBUG4 ctrl: {ctrl}')
            data = mjx_env.init(self.mjx_model, qpos=qpos, qvel=qvel, ctrl=ctrl)
            rng, cmd_rng = jax.random.split(rng)
            cmd = self.sample_command(cmd_rng)

            # Sample push interval.
            rng, push_rng = jax.random.split(rng)
            push_interval = jax.random.uniform(
                push_rng,
                minval=self._config.push_config.interval_range[0],
                maxval=self._config.push_config.interval_range[1],
            )
            push_interval_steps = jp.round(push_interval / self.dt).astype(jp.int32)

            if USE_IMITATION_REWARD:
                current_reference_motion = self.PRM.get_reference_motion(
                    cmd[0], cmd[1], cmd[2], 0
                )
            else:
                current_reference_motion = jp.zeros(0)

            info = {
                "rng": rng,
                "step": 0,
                "command": cmd,
                "last_act": jp.zeros(self.mjx_model.nu),
                "last_last_act": jp.zeros(self.mjx_model.nu),
                "last_last_last_act": jp.zeros(self.mjx_model.nu),
                "motor_targets": ctrl,
                "feet_air_time": jp.zeros(2),
                "last_contact": jp.zeros(2, dtype=bool),
                "swing_peak": jp.zeros(2),
                # Push related.
                "push": jp.array([0.0, 0.0]),
                "push_step": 0,
                "push_interval_steps": push_interval_steps,
                # History related.
                "action_history": jp.zeros(
                    self._config.noise_config.action_max_delay * self._actuators
                ),
                "imu_history": jp.zeros(self._config.noise_config.imu_max_delay * 3),
                # imitation related
                "imitation_i": 0,
                "current_reference_motion": current_reference_motion,
                "imitation_phase": jp.zeros(2),
            }

            metrics = {}
            for k, v in self._config.reward_config.scales.items():
                if v != 0:
                    if v > 0:
                        metrics[f"reward/{k}"] = jp.zeros(())
                    else:
                        metrics[f"cost/{k}"] = jp.zeros(())
            metrics["swing_peak"] = jp.zeros(())

            contact = jp.array(
                [
                    geoms_colliding(data, geom_id, self._floor_geom_id)
                    for geom_id in self._feet_geom_id
                ]
            )
            obs = self._get_obs(data, info, contact)
            reward, done = jp.zeros(2)
            return mjx_env.State(data, obs, reward, done, metrics, info)

        def step(self, state: mjx_env.State, action: jax.Array) -> mjx_env.State:

            if USE_IMITATION_REWARD:
                state.info["imitation_i"] += 1
                state.info["imitation_i"] = (
                    state.info["imitation_i"] % self.PRM.nb_steps_in_period
                )  # not critical, is already moduloed in get_reference_motion
                state.info["imitation_phase"] = jp.array(
                    [
                        jp.cos(
                            (state.info["imitation_i"] / self.PRM.nb_steps_in_period)
                            * 2
                            * jp.pi
                        ),
                        jp.sin(
                            (state.info["imitation_i"] / self.PRM.nb_steps_in_period)
                            * 2
                            * jp.pi
                        ),
                    ]
                )
            else:
                state.info["imitation_i"] = 0

            if USE_IMITATION_REWARD:
                state.info["current_reference_motion"] = self.PRM.get_reference_motion(
                    state.info["command"][0],
                    state.info["command"][1],
                    state.info["command"][2],
                    state.info["imitation_i"],
                )
            else:
                state.info["current_reference_motion"] = jp.zeros(0)

            state.info["rng"], push1_rng, push2_rng, action_delay_rng = jax.random.split(
                state.info["rng"], 4
            )

            # Handle action delay
            action_history = (
                jp.roll(state.info["action_history"], self._actuators)
                .at[: self._actuators]
                .set(action)
            )
            state.info["action_history"] = action_history
            action_idx = jax.random.randint(
                action_delay_rng,
                (1,),
                minval=self._config.noise_config.action_min_delay,
                maxval=self._config.noise_config.action_max_delay,
            )
            action_w_delay = action_history.reshape((-1, self._actuators))[
                action_idx[0]
            ]  # action with delay

            # self.action_filter.push(action_w_delay)
            # action_w_delay = self.action_filter.get_filtered_action()

            push_theta = jax.random.uniform(push1_rng, maxval=2 * jp.pi)
            push_magnitude = jax.random.uniform(
                push2_rng,
                minval=self._config.push_config.magnitude_range[0],
                maxval=self._config.push_config.magnitude_range[1],
            )
            push = jp.array([jp.cos(push_theta), jp.sin(push_theta)])
            push *= (
                jp.mod(state.info["push_step"] + 1, state.info["push_interval_steps"]) == 0
            )
            push *= self._config.push_config.enable
            qvel = state.data.qvel
            qvel = qvel.at[
                self._floating_base_qvel_addr : self._floating_base_qvel_addr + 2
            ].set(
                push * push_magnitude
                + qvel[self._floating_base_qvel_addr : self._floating_base_qvel_addr + 2]
            )  # floating base x,y
            data = state.data.replace(qvel=qvel)
            state = state.replace(data=data)

            ####

            # OLD:
            # motor_targets = (
            #     self._default_actuator + action_w_delay * self._config.action_scale
            # )
            # if USE_MOTOR_SPEED_LIMITS:
            #     prev_motor_targets = state.info["motor_targets"]
            #     motor_targets = jp.clip(
            #         motor_targets,
            #         prev_motor_targets
            #         - self._config.max_motor_velocity * self.dt,
            #         prev_motor_targets
            #         + self._config.max_motor_velocity * self.dt,
            #     )

            # NEW HYBRID (absolute target + smooth slew limit)
            prev_motor_targets = state.info["motor_targets"]  # <<< CHANGED
            motor_targets = self._compute_motor_targets(      # <<< CHANGED
                prev_motor_targets,
                action_w_delay,
            )

            # motor_targets.at[5:9].set(state.info["command"][3:])  # head joints
            data = mjx_env.step(self.mjx_model, state.data, motor_targets, self.n_substeps)

            state.info["motor_targets"] = motor_targets

            contact = jp.array(
                [
                    geoms_colliding(data, geom_id, self._floor_geom_id)
                    for geom_id in self._feet_geom_id
                ]
            )
            contact_filt = contact | state.info["last_contact"]
            first_contact = (state.info["feet_air_time"] > 0.0) * contact_filt
            state.info["feet_air_time"] += self.dt
            p_f = data.site_xpos[self._feet_site_id]
            p_fz = p_f[..., -1]
            state.info["swing_peak"] = jp.maximum(state.info["swing_peak"], p_fz)

            obs = self._get_obs(data, state.info, contact)
            done = self._get_termination(data)

            rewards = self._get_reward(
                data, action, state.info, state.metrics, done, first_contact, contact
            )
            # FIXME
            rewards = {
                k: v * self._config.reward_config.scales[k] for k, v in rewards.items()
            }
            reward = jp.clip(sum(rewards.values()) * self.dt, 0.0, 10000.0)
            # jax.debug.print('STEP REWARD: {}',reward)
            state.info["push"] = push
            state.info["step"] += 1
            state.info["push_step"] += 1
            state.info["last_last_last_act"] = state.info["last_last_act"]
            state.info["last_last_act"] = state.info["last_act"]
            state.info["last_act"] = action  # was
            # state.info["last_act"] = motor_targets  # became
            state.info["rng"], cmd_rng = jax.random.split(state.info["rng"])
            state.info["command"] = jp.where(
                state.info["step"] > 500,
                self.sample_command(cmd_rng),
                state.info["command"],
            )
            state.info["step"] = jp.where(
                done | (state.info["step"] > 500),
                0,
                state.info["step"],
            )
            state.info["feet_air_time"] *= ~contact
            state.info["last_contact"] = contact
            state.info["swing_peak"] *= ~contact
            for k, v in rewards.items():
                rew_scale = self._config.reward_config.scales[k]
                if rew_scale != 0:
                    if rew_scale > 0:
                        state.metrics[f"reward/{k}"] = v
                    else:
                        state.metrics[f"cost/{k}"] = -v
            state.metrics["swing_peak"] = jp.mean(state.info["swing_peak"])

            done = done.astype(reward.dtype)
            state = state.replace(data=data, obs=obs, reward=reward, done=done)
            return state
