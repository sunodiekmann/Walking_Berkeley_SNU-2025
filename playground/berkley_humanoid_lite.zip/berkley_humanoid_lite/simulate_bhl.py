import mujoco
import mujoco.viewer

model = mujoco.MjModel.from_xml_path("berkley_humanoid_lite/xmls/scene_flat_terrain.xml")
data = mujoco.MjData(model)

# Optional: set initial height to prevent fall-through
data.qpos[2] = 0.3

with mujoco.viewer.launch_passive(model, data):
    print("Viewer running — press ESC to exit.")
